
cp=config_xq
for f in lib/*.jar
do
	cp="$cp:$f"
done


export CLASSPATH="$cp"

nohup java gyf.test.scala.Main xq >/dev/null 2>&1 &

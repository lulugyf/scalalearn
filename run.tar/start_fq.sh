
cp=config_fq
for f in lib/*.jar
do
	cp="$cp:$f"
done


export CLASSPATH="$cp"

nohup java gyf.test.scala.Main fq >/dev/null 2>&1 &
